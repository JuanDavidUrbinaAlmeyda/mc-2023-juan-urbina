import copy
import math
x=[1,1,2,3,1,2,3,3]
xb=[0,1,1,2,2,3,3,1]
y=[3.2,6,2.2,2.5,6.5,6.6,3.5,0.2]
sumx=0
sumy=0
sumx2=0
sumxb=0
sumxb2=0
sumxxb=0
sumxy=0
sumxby=0

for elementos in range(len(x)):
    sumx=x[elementos]+sumx
    sumy=y[elementos]+sumy
    sumx2=((x[elementos])**2)+sumx2
    sumxb=xb[elementos]+sumxb
    sumxb2=((xb[elementos])**2)+sumxb2
    sumxxb=(x[elementos]*xb[elementos])+sumxxb
    sumxy=(x[elementos]*y[elementos])+sumxy
    sumxby=(xb[elementos]*y[elementos])+sumxby
promy=sumy/len(y)

print("1) ",len(x),"a0 + ",sumx,"a1 + ",sumxb,"a2 = ",sumy,"\n2) ",sumx,"a0 + ",sumx2,"a1 + ",sumxxb,"a2 = ",sumxy,"\n3) ",sumxb,"a0 + ",sumxxb,"a1 + ",sumxb2,"a2 = ",sumxby)
def imprimirSistema(a, b, etiqueta):
    n = len(b)
    print(etiqueta)
    for i in range(n):
        for j in range(n):
            print(a[i][j], end = " ")
        print("|", b[i])
    print()

def gaussJordan(ao, bo):
    a = copy.deepcopy(ao)
    b = copy.copy(bo)

    n = len(b)
    
    imprimirSistema(a, b, "Matriz inicial")
    for i in range(n):
        #Pivoteo-------------------------------------------------------------
        if a[i][i]==0:
            #Cambiar Ecuación
            for t in range (i+1,n):
                if a[t][i]!=0:
                    a[i], a[t] = a[t], a[i]
                    b[i], b[t] = b[t], b[i]
                    break

        pivote = a[i][i]

        #Dividir por el pivote-----------------------------------------------------
        for j in range(n):
            a[i][j] /= pivote

        b[i] /= pivote
        imprimirSistema(a, b, "División")

        #Reducción
        for k in range(n):
            if i != k:
                #Se reduce
                valorAux = -a[k][i]
                for j in range(n):
                    a[k][j] += a[i][j] * valorAux
                b[k] += b[i] * valorAux
        imprimirSistema(a, b, "Reducción")
    
    return b

a=[[len(x),sumx,sumxb],[sumx,sumx2,sumxxb],[sumxb,sumxxb,sumxb2]]
b=[sumy,sumxy,sumxby]
mat = gaussJordan(a, b)

print("Respuesta:")
for i in range(len(mat)):
    print("a" + str(i), "=", mat[i])

a0=mat[0]
a1=mat[1]
a2=mat[2]
print("y = (",a0,") + (",a1,")x1 + (",a2,")x2")
st=0
sr=0
for elements in range (len(y)):
    st=((y[elements]-promy)**2)+st
    sr=((y[elements]-a0-a1*x[elements]-a2*xb[elements])**2)+sr
print("st = ",st,"\nsr = ",sr)
sy=math.sqrt(st/(len(x)-1))
syx=math.sqrt(sr/(len(x)-3))
print("sy = ",sy,"\nsy/x = ",syx)
r=(math.sqrt((st-sr)/st))*100
r2=(st-sr)/st
print("r = ",r,"%\nr^2 = ",r2)