#Juan David Urbina Almeyda
import math
x=[2,4,6,8,10,12]
y=[2.2,3,4.5,6,8.5,12]
lny=[]
xlny=[]
sumx=0
sumlny=0
xsquare=[]
sumsquare=0
sumxy=0

for w in range(len(y)):
    lny.append(math.log(y[w]))
    
for i in range(len(x)):
    xlny.append(x[i]*lny[i])


for k in range(len(x)):
    sumx=sumx+x[k]

for j in range(len(y)):
    sumlny=sumlny+lny[j]

for h in range(len(x)):
    xsquare.append(x[h]*x[h])

for t in range(len(x)):
    sumsquare=sumsquare+xsquare[t]
    
for u in range(len(x)):
    sumxy=sumxy+xlny[u]
    
promx=sumx/len(x)
promy=sumlny/len(y)

a1=(((len(x)*sumxy)-(sumx*sumlny))/((len(x)*sumsquare)-(sumx*sumx)))
ao=promy-(a1*promx)
print("ao= ",ao)
print("a1= ",a1)
alpha=math.pow(math.e,ao)
beta=a1
print("y= ",alpha,"e ^",beta,"x")

