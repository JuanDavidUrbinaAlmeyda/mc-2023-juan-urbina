
#Juan David Urbina Almeyda
x=[0,1,2,3,4,5,6,7]
y=[3.5,2.5,3,1.5,2,1.3,1,0.3]
xy=[]
sumx=0
sumy=0
xsquare=[]
sumsquare=0
sumxy=0

for i in range(len(x)):
    xy.append(x[i]*y[i])
print(xy)
for k in range(len(x)):
    sumx=sumx+x[k]

for j in range(len(y)):
    sumy=sumy+y[j]

for h in range(len(x)):
    xsquare.append(x[h]*x[h])

for t in range(len(x)):
    sumsquare=sumsquare+xsquare[t]
    
for u in range(len(x)):
    sumxy=sumxy+xy[u]
    
promx=sumx/len(x)
promy=sumy/len(y)

a1=(((len(x)*sumxy)-(sumx*sumy))/((len(x)*sumsquare)-(sumx*sumx)))
ao=promy-(a1*promx)
print("y= ",ao," + (",a1,"x)")

