import copy
import math
x=[0,1,2,3,4,5,6]
y=[4.2,1.4,0,-0.4,-0.1,1.6,4.1]
sumx=0
sumy=0
sumx2=0
sumx3=0
sumx4=0
sumxy=0
sumx2y=0

for elementos in range(len(x)):
    sumx=x[elementos]+sumx
    sumy=y[elementos]+sumy
    sumx2=((x[elementos])**2)+sumx2
    sumx3=((x[elementos])**3)+sumx3
    sumx4=((x[elementos])**4)+sumx4
    sumxy=(x[elementos]*y[elementos])+sumxy
    sumx2y=(((x[elementos])**2)*y[elementos])+sumx2y
promy=sumy/len(y)

print(len(x),"a0 + ",sumx,"a1 + ",sumx2,"a2 = ",sumy,"\n ",sumx,"ao + ",sumx2,"a1 + ",sumx3,"a2 = ",sumxy,"\n ",sumx2,"a0 + ",sumx3,"a1 + ",sumx4,"a2 = ",sumx2y)

def imprimirSistema(a, b, etiqueta):
    n = len(b)
    print(etiqueta)
    for i in range(n):
        for j in range(n):
            print(a[i][j], end = " ")
        print("|", b[i])
    print()

def gaussJordan(ao, bo):
    a = copy.deepcopy(ao)
    b = copy.copy(bo)

    n = len(b)
    
    imprimirSistema(a, b, "Matriz inicial")
    for i in range(n):
        #Pivoteo-------------------------------------------------------------
        if a[i][i]==0:
            #Cambiar Ecuación
            for t in range (i+1,n):
                if a[t][i]!=0:
                    a[i], a[t] = a[t], a[i]
                    b[i], b[t] = b[t], b[i]
                    break

        pivote = a[i][i]

        #Dividir por el pivote-----------------------------------------------------
        for j in range(n):
            a[i][j] /= pivote

        b[i] /= pivote
        imprimirSistema(a, b, "División")

        #Reducción
        for k in range(n):
            if i != k:
                #Se reduce
                valorAux = -a[k][i]
                for j in range(n):
                    a[k][j] += a[i][j] * valorAux
                b[k] += b[i] * valorAux
        imprimirSistema(a, b, "Reducción")
    
    return b

a = [[len(x), sumx, sumx2], [sumx, sumx2, sumx3], [sumx2, sumx3, sumx4]]
b = [sumy, sumxy, sumx2y]
mat = gaussJordan(a, b)

print("Respuesta:")
for i in range(len(mat)):
    print("a" + str(i), "=", mat[i])

a0=mat[0]
a1=mat[1]
a2=mat[2]
print("y = (",a0,") + (",a1,")x + (",a2,")x2")
st=0
sr=0
for elements in range (len(y)):
    st=((y[elements]-promy)**2)+st
    sr=((y[elements]-a0-a1*x[elements]-a2*(x[elements]**2))**2)+sr
print("st = ",st,"\nsr = ",sr)
sy=math.sqrt(st/(len(x)-1))
syx=math.sqrt(sr/(len(x)-3))
print("sy = ",sy,"\nsy/x = ",syx)
r=(math.sqrt((st-sr)/st))*100
print("r = ",r,"%")