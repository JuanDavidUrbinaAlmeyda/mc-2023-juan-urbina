
#Taller XXII.2
import numpy as np
import sympy as sym

xi=[0,1,2,3,4]
y=[1,0.9,-1,-2.3,1.8]
n=len(xi)
x=sym.Symbol('x')

i=0
pol=0
for i in range(n):
    num=1
    den=1
    for j in range(n):
        if i != j:
            num=num*(x-xi[j])
            den=den*(xi[i]-xi[j])
        termino=(num/den)*y[i]
    pol=pol+termino
polsim=sym.expand(pol)
    
        
print('Polinomio')
print(pol)
print('Polinomio Simple')
print(polsim)