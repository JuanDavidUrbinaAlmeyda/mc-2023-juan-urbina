#Taller XVIII JDUA
import math
x=[0.5,1.5,2.5,3.5,4.5,5.5,6.5,7.5]
y=[4.2,6.5,7.5,8,8.5,8.8,9,9.1]
print("-----MODELO LINEAL-----")
xy=[]
sumx=0
sumy=0
xsquare=[]
sumsquare=0
sumxy=0

for i in range(len(x)):
    xy.append(x[i]*y[i])
print(xy)
for k in range(len(x)):
    sumx=sumx+x[k]

for j in range(len(y)):
    sumy=sumy+y[j]

for h in range(len(x)):
    xsquare.append(x[h]*x[h])

for t in range(len(x)):
    sumsquare=sumsquare+xsquare[t]
    
for u in range(len(x)):
    sumxy=sumxy+xy[u]
    
promx=sumx/len(x)
promy=sumy/len(y)

a1=(((len(x)*sumxy)-(sumx*sumy))/((len(x)*sumsquare)-(sumx*sumx)))
ao=promy-(a1*promx)
print("y= ",ao," + (",a1,"x)")
print(" ")
print("-----MODELO EXPONENCIAL-----")
lny=[]
xlny=[]
sumx=0
sumlny=0
xsquare=[]
sumsquare=0
sumxy=0

for w in range(len(y)):
    lny.append(math.log(y[w]))
    
for i in range(len(x)):
    xlny.append(x[i]*lny[i])


for k in range(len(x)):
    sumx=sumx+x[k]

for j in range(len(y)):
    sumlny=sumlny+lny[j]

for h in range(len(x)):
    xsquare.append(x[h]*x[h])

for t in range(len(x)):
    sumsquare=sumsquare+xsquare[t]
    
for u in range(len(x)):
    sumxy=sumxy+xlny[u]
    
promx=sumx/len(x)
promy=sumlny/len(y)

a1=(((len(x)*sumxy)-(sumx*sumlny))/((len(x)*sumsquare)-(sumx*sumx)))
ao=promy-(a1*promx)
print("ao= ",ao)
print("a1= ",a1)
alpha=math.pow(math.e,ao)
beta=a1
print("y= ",alpha,"e ^",beta,"x")
print(" ")
print("-----MODELO DE ECUACION DE POTENCIAS-----")
sumlogx=0
sumlogy=0
sumlogs=0
sumlogsquare=0

for values in range (len(x)):
    sumlogx+= math.log10(x[values])
    sumlogy+= math.log10(y[values])
    sumlogs+=(math.log10(x[values])*math.log10(y[values]))
    sumlogsquare+= ((math.log10(x[values]))**2)
promlogx=sumlogx/len(x)
promlogy=sumlogy/len(y)

a1log=(((len(x)*sumlogs)-(sumlogx*sumlogy))/((len(x)*sumlogsquare)-(sumlogx*sumlogx)))
aolog=promlogy-(a1log*promlogx)
print("ao= ",aolog)
print("a1= ",a1log)
alffa=math.pow(10,aolog)
betta=a1log
print("y= ",alffa,"x^",betta)
print(" ")
print("-----MODELO DE RAZON DE CRECIMIENTO-----")
suminvx=0
suminvy=0
suminvs=0
suminvsquare=0

for s in range(len(x)):
    suminvx += 1/x[s]
    suminvy += 1/y[s]
    suminvs += (1/x[s] * 1/y[s])
    suminvsquare += ((1/x[s])**2)


prominvx=suminvx/len(x)
prominvy=suminvy/len(y)

a1razon=(((len(x)*suminvs)-(suminvx*suminvy))/((len(x)*suminvsquare)-(suminvx*suminvx)))
aorazon=prominvy-(a1razon*prominvx)
print("ao= ",aorazon)
print("a1= ",a1razon)
alpha=1/aorazon
betha=a1razon/aorazon
print("y= ",alpha,"*(x/",betha,"+x)")
