
def crearmatriz(a,b):
    m=[]
    for i in range(a):
        fila=[]
        for k in range(b):
            value=int(input("Valor: "))
            fila.append(value)
        m.append(fila)        
    return m

print("-----Matriz 1-----")
m1=int(input("Número de filas de la primera matriz: "))
n1=int(input("Número de columnas de la primera matriz: "))
mat1=crearmatriz(m1,n1)
print(mat1)
print("-----Matriz 2-----")
mat2=[[]]
m2=int(input("Número de filas de la segunda matriz: "))
n2=int(input("Número de columnas de la segunda matriz: "))
mat2=crearmatriz(m2,n2)
print(mat2)
op=int(input("Escriba \n 1. Para producto de A por escalar \n 2. Para producto de B por escalar \n 3. Para Suma de Matrices \n 4. Para el producto "))
if op==1:
    print("---Producto de A por escalar-----")
    for r in range(m1):
        for z in range(n1):
            val=mat1[r][z]
            nv=val*3
            mat1[r][z]=nv
    print(mat1)
elif op==2:
    print("---Producto de B por escalar---")
    for v in range(m2):
        for q in range(n2):
            val=mat2[v][q]
            nv=val*4
            mat2[v][q]=nv
    print(mat2)
elif op==3:
    print("---Suma de Matrices---")
    if m1==m2 and n1==n2:
        for h in range(m1):
            for g in range(n1):
                val=mat1[h][g]
                val2=mat2[h][g]
                nv=val+val2
                mat1[h][g]=nv
    else:
        print("No se puede realizar la suma")

elif op==4:
    print("---Producto entre dos matrices---")
    if n2==m1:
        resultado = [[0 for j in range(n2)] for i in range(m1)]
    else:
        print("No se puede realizar el producto")
    for i in range(m1):
        for j in range(n2):
            for k in range(n1):
                resultado[i][j] += mat1[i][k] * mat2[k][j]
    print("El producto de las matrices es:")
    for fila in resultado:
        print(fila)