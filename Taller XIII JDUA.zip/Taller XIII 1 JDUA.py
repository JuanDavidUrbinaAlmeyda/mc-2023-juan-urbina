


v1=[]
v2=[]
print("----VECTOR 1----")
n1=int(input("Longitud de los vectores: "))
for i in range(0,n1):
    valor=int(input("Valor: "))
    v1.insert(i,valor)
print(v1)


print("----VECTOR 2-----")
for k in range (0,n1):
    valor=int(input("Valor: "))
    v2.insert(k,valor)
print(v2)    


suma=0
for w in range (0,n1):
    suma=suma+(v1[w]*v2[w])
    
print("El producto escalar es: ",suma)
  
